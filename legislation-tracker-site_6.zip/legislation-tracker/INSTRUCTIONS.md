# Legislation Tracker — hosting & update guide

The dashboard is the single file `index.html` in this folder. Everything (map, data,
styling) is inside it — no server, database or internet connection is required for it
to work. Hosting it just gives it a permanent URL you and colleagues can bookmark.

## One-time setup — GitHub Pages
Already done if you followed earlier instructions: upload `index.html` to your repo,
enable GitHub Pages (Settings -> Pages -> Deploy from branch -> main -> / root).

## Each update cycle (~1 minute)
1. Ask for a refresh: upload the current `index.html` (or paste your live URL) and
   ask to re-verify and rebuild for today.
2. Rename the new file to `index.html`.
3. In your GitHub repo: Add file -> Upload files -> drop the new `index.html` in ->
   Commit changes. Same filename replaces the old version.
4. Wait about a minute, then refresh the live URL.

## Notes
- All tracker data lives inside `index.html` itself — no separate spreadsheet needed.
- The dashboard's scope covers all continents, national and sub-national/state laws,
  where highly relevant to human rights and sustainability supply chain due diligence.
- Rows marked "provisional" in this cycle (Guatemala, Honduras, Trinidad and Tobago)
  were added from a primary US government source but not yet independently verified
  in the underlying country's own legal text — flag these for a closer look next cycle.
